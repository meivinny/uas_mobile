import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'list.dart';
import 'list1.dart';
import 'list2.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Suki Hobby Shop',
        theme: ThemeData(
          primaryColor: Colors.black,
          primarySwatch: Colors.grey,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: MyHomePage(),
        debugShowCheckedModeBanner: false);
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  PageController pageController = PageController();
  int pageCount = 3;

  @override
  void initState() {
    super.initState();
    Timer.periodic(Duration(seconds: 3), (timer) {
      print("page ${pageController.page}");
      if (pageController.page >= pageCount - 1) {
        pageController.animateToPage(0,
            duration: Duration(milliseconds: 1000),
            curve: Curves.fastLinearToSlowEaseIn);
      } else {
        pageController.nextPage(
            duration: Duration(milliseconds: 1000),
            curve: Curves.fastLinearToSlowEaseIn);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        centerTitle: false,
        title: Container(
            child: SizedBox(
                width: 100,
                height: 40,
                child: Image.network(
                    "http://sukihobbytoys.000webhostapp.com/gambar/slide/logo.png"))),
        actions: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              children: [
                Icon(
                  Icons.message,
                  size: 34.0,
                )
              ],
            ),
          )
        ],
      ),
      body: Container(
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("Selamat Datang di , Suki Hobby Toys ",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            LimitedBox(
              maxHeight: 250,
              child: Stack(
                children: [
                  PageView(
                    controller: pageController,
                    children: [
                      SlideCard(
                          slideimage:
                              "http://sukihobbytoys.000webhostapp.com/gambar/slide/slide1.jpg"),
                      SlideCard(
                        slideimage:
                            "http://sukihobbytoys.000webhostapp.com/gambar/slide/slide2.jpg",
                      ),
                      SlideCard(
                        slideimage:
                            "http://sukihobbytoys.000webhostapp.com/gambar/slide/slide3.jfif",
                      )
                    ],
                  ),
                  Positioned(
                      bottom: 18.0,
                      left: 0.0,
                      right: 0.0,
                      child: Center(
                        child: Slideindikator(
                          pageController: pageController,
                        ),
                      ))
                ],
              ),
            ),
            Container(
              color: Colors.grey[200],
              height: 8,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("Promosi ",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: LimitedBox(
                maxHeight: 192,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    Promosi(
                        promo:
                            "http://sukihobbytoys.000webhostapp.com/gambar/pvc/71054-pvc-figure-maurys-touring-restaurant-velvet-single-item.jpg"),
                    Promosi(
                        promo:
                            "http://sukihobbytoys.000webhostapp.com/gambar/pvc/71055-pvc-figure-maurys-touring-restaurant-gwendolyn-single-item.jpg"),
                    Promosi(
                        promo:
                            "http://sukihobbytoys.000webhostapp.com/gambar/pvc/71056-pvc-figure-maurys-touring-restaurant-mercedes-single-item.jpg"),
                    Promosi(
                        promo:
                            "http://sukihobbytoys.000webhostapp.com/gambar/pvc/71100-pvc-figure-14-kurumi-tokisaki-bunny-ver.jpg"),
                    Promosi(
                        promo:
                            "http://sukihobbytoys.000webhostapp.com/gambar/pvc/71068-pvc-figure-16-koumyou-no-shitenshi-sakuya-mode-seraphim.jpg")
                  ],
                ),
              ),
            ),
            Container(
              color: Colors.grey[200],
              height: 8,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("PVC ",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: LimitedBox(
                maxHeight: 192,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    Promosi(
                        promo:
                            "http://sukihobbytoys.000webhostapp.com/gambar/pvc/71063-pvc-figure-17-noire-black-heart-hyperdimension-neptunia-re-release.jpg"),
                    Promosi(
                        promo:
                            "http://sukihobbytoys.000webhostapp.com/gambar/pvc/71064-pvc-figure-17-neptune-purple-heart-hyperdimension-neptunia-re-release.jpg"),
                    Promosi(
                        promo:
                            "http://sukihobbytoys.000webhostapp.com/gambar/pvc/71068-pvc-figure-16-koumyou-no-shitenshi-sakuya-mode-seraphim.jpg"),
                    Promosi(
                        promo:
                            "http://sukihobbytoys.000webhostapp.com/gambar/pvc/71074-pvc-figure-17-black-rock-shooter-inexhaustible-ver.jpg"),
                    Promosi(
                        promo:
                            "http://sukihobbytoys.000webhostapp.com/gambar/pvc/71079-pvc-figure-17-hatsune-miku-magical-mirai-2020-winter-festival-ver.jpg")
                  ],
                ),
              ),
            ),
            Container(
              color: Colors.grey[200],
              height: 8,
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Text("Categories ",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                children: [
                  MenuFeature(
                    iconAsset:
                        "http://sukihobbytoys.000webhostapp.com/gambar/figma/70114-figma-satonaka-chie-persona-4.jpg",
                    name: "PVC",
                  ),
                  MenuFeature1(
                    iconAsset:
                        "http://sukihobbytoys.000webhostapp.com/gambar/nendoroid/70617-nendoroid-hatsune-miku-v4x-vocaloid.jpg",
                    name: "Nendoroid",
                  ),
                  MenuFeature2(
                    iconAsset:
                        "http://sukihobbytoys.000webhostapp.com/gambar/pvc/71071-pvc-figure-17-eriri-spencer-sawamura-lingerie-ver.jpg",
                    name: "Figma",
                  ),
                ],
              ),
            ),
            Container(
              color: Colors.grey[200],
              height: 8,
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          unselectedItemColor: Colors.grey,
          selectedItemColor: Colors.green,
          items: [
            BottomNavigationBarItem(
                icon: Icon(Icons.home), title: Text("Home")),
            BottomNavigationBarItem(
                icon: Icon(Icons.search), title: Text("Search")),
            BottomNavigationBarItem(
                icon: Icon(Icons.shopping_cart), title: Text("Wishlist")),
            BottomNavigationBarItem(
                icon: Icon(Icons.account_circle), title: Text("Account")),
          ]),
    );
  }
}

class Slideindikator extends AnimatedWidget {
  final PageController pageController;
  Slideindikator({this.pageController}) : super(listenable: pageController);
  @override
  Widget build(BuildContext context) {
    return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List<Widget>.generate(3, buildIndikator));
  }

  Widget buildIndikator(int index) {
    print("build $index ");
    double select = max(
      0.0,
      1.0 - ((pageController.page ?? pageController.initialPage) - index).abs(),
    );
    double decrease = 10 * select;
    return Container(
      width: 30,
      child: Center(
        child: Container(
          width: 20 - decrease,
          height: 5,
          decoration: BoxDecoration(
              color: Colors.black, borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }
}

class Promosi extends StatelessWidget {
  final String promo;
  Promosi({this.promo});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => DataFigureHome()));
      },
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: Container(
          height: 190,
          width: 185,
          child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(promo)),
        ),
      ),
    );
  }
}

class MenuFeature extends StatelessWidget {
  final String iconAsset;
  final String name;
  MenuFeature({this.iconAsset, this.name});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => DataFigureHome()));
      },
      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),
        child: Column(
          children: [
            SizedBox(width: 100, height: 100, child: Image.network(iconAsset)),
            Text(
              name,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            )
          ],
        ),
      ),
    );
  }
}

class MenuFeature1 extends StatelessWidget {
  final String iconAsset;
  final String name;
  MenuFeature1({this.iconAsset, this.name});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => DataFigureHome1()));
      },
      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),
        child: Column(
          children: [
            SizedBox(width: 100, height: 100, child: Image.network(iconAsset)),
            Text(
              name,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            )
          ],
        ),
      ),
    );
  }
}

class MenuFeature2 extends StatelessWidget {
  final String iconAsset;
  final String name;
  MenuFeature2({this.iconAsset, this.name});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => DataFigureHome2()));
      },
      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),
        child: Column(
          children: [
            SizedBox(width: 100, height: 100, child: Image.network(iconAsset)),
            Text(
              name,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            )
          ],
        ),
      ),
    );
  }
}

class SlideCard extends StatelessWidget {
  final String slideimage;
  SlideCard({this.slideimage});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: Container(
          height: 200,
          child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(slideimage)),
        ),
      ),
    );
  }
}
