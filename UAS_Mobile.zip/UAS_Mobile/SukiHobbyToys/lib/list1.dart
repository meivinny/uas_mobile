import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'detail_figure1.dart';
// ignore: unused_import
import 'package:carousel_pro/carousel_pro.dart';

class DataFigureHome1 extends StatefulWidget {
  @override
  _DataFigureHomeState createState() => _DataFigureHomeState();
}

class _DataFigureHomeState extends State<DataFigureHome1> {
//get data JSON

  Future<List> getData() async {
    final responseData =
        await get("http://sukihobbytoys.000webhostapp.com/list1.php");
    return json.decode(responseData.body);
  }

  @override
  Widget build(BuildContext context) {
    //Implementasi GUI JSON kedalam list
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Suki Hobby Shop'),
        backgroundColor: Colors.blue,
      ),
      body: FutureBuilder<List>(
        future: getData(),
        builder: (context, snapshot) {
          if (snapshot.hasError) print(snapshot.error);
          //jk tidk eror maka
          return snapshot.hasData
              ? ItemList(list: snapshot.data)
              : Center(
                  child: CircularProgressIndicator(),
                );
        },
      ),
    );
  }
}

//class ItemList
class ItemList extends StatelessWidget {
  final List list;
  ItemList({this.list});
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: list == null ? 0 : list.length,
      itemBuilder: (context, i) {
        return Stack(
          children: <Widget>[
            GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => DetailPageFigure1(
                              list: list,
                              index: i,
                            )));
              },
              child: Container(
                margin: EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 5.0),
                height: 170.0,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10.0),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 2,
                      blurRadius: 2,
                      offset: Offset(0, 3), // changes position of shadow
                    ),
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.fromLTRB(160, 0, 10.0, 10.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            width: 150.0,
                            child: Text(
                              list[i]['nama_nendoroid'],
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 18.0,
                                fontWeight: FontWeight.w600,
                              ),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 3,
                            ),
                          ),
                          Icon(
                            FontAwesomeIcons.heart,
                            color: Colors.grey,
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 40.0,
                      ),
                      Row(
                        children: <Widget>[
                          Container(
                            width: 180.0,
                            child: Text(
                              'Rp ' + list[i]['harga_nendoroid'],
                              style: TextStyle(
                                  fontSize: 18.0,
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          Icon(
                            FontAwesomeIcons.shoppingCart,
                            color: Colors.blueGrey,
                            size: 18,
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              left: 15.0,
              top: 10.0,
              bottom: 10,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10.0),
                child: Image.network(
                  'http://sukihobbytoys.000webhostapp.com/gambar/nendoroid/' +
                      list[i]['gambar_nendoroid'],
                  width: 150.0,
                  fit: BoxFit.cover,
                ),
              ),
            )
          ],
        );
      },
    );
  }
}
