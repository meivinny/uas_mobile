package com.matana.ivanocrey.SukiHobbyToys

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
